

You wake up in an office! You are hungry and looking for some 
TiTap! The manager has some, hidden somewhere!

You are a TiTap Warrior and your task is finding that little piece of cake - although this task is not a piece of cake! 

Follow the clues/notes and you will find what you WANT! 

here is your first clue: go into the NEWEST directory (ooni ke ba'd az hame sakhte shode) and check the file "note.txt".





















